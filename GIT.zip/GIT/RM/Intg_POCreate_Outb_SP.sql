/********************************************************************************/
/*FILENAME = Intg_POCreate_Outb_SP.SQL											*/
/********************************************************************************/
/* PROCEDURE       Intg_POCreate_Outb_SP										*/
/* DESCRIPTION     Purchase Order Creation										*/
/********************************************************************************/
/* PROJECT        Ramco Integration												*/
/* VERSION        1.0															*/
/********************************************************************************/
/* 						DEVELOPMENT HISTORY										*/
/********************************************************************************/
/* AUTHOR		  Preethi S														*/
/* DATE           26 Feb 2024													*/
/* Rtrack		  APSI-1834														*/
/********************************************************************************/
/* 						MODIFICATION HISTORY									*/
/********************************************************************************/
/* ModifiedBy					ModifiedDate						RtrackID	*/
--	Ramya M 15230
/********************************************************************************/

--	alter table Intg_POCreate_Outb_Stg add stgrowid udd_int		
--alter table Intg_POCreate_Outb_Stg add batchid udd_guid
--alter table Intg_POCreate_Outb_Stg alter column ShipByAddress nvarchar(30)
--ALTER TABLE Intg_POCreate_Outb_iRIS ALTER COLUMN XMLDATA XML
--alter table Intg_POResp_Outb_Tbl alter column SaleDocNo udd_txt150 
--alter table Intg_POCreate_Outb_Stg alter column SaleOrder_No udd_txt150
--alter table Intg_POResp_Outb_Tbl add tranid udd_guid
--CREATE SYNONYM PO_POudi_user_def_info FOR AVNAPPDB.DBO.PO_POudi_user_def_info
--alter table  Intg_POCreate_Outb_iRIS  add stgrowid udd_int	
--alter table  Intg_POCreate_Outb_iRIS  add PO_NO udd_documentno	
			
CREATE PROCEDURE [dbo].[Intg_POCreate_Outb_SP]
@CtxtOuinstance_In	ctxt_ouinstance,
@InterfaceId_In		udd_documentno,
@MessageId_In		udd_guid,
@TranId_In			udd_guid,
@Processflag_In		udd_flag

AS 
BEGIN
SET NOCOUNT ON

	DECLARE	@V_Ctxt_Ouinstance		ctxt_ouinstance	DECLARE	@V_Ctxt_User			ctxt_user			DECLARE	@V_InterfaceID			udd_guid		
	DECLARE	@V_InterfaceDesc		udd_txt150		DECLARE	@V_DefaultDate			udd_datetime1		DECLARE	@V_TranID				udd_guid
	DECLARE	@V_ExecStatus			udd_flag		DECLARE	@V_ExecStatusSuccess	udd_flag			DECLARE	@V_ExecStatusInprog		udd_flag
	DECLARE	@V_ExecStatusFail		udd_flag		DECLARE	@V_ExecStatusCError		udd_flag			DECLARE	@V_ErrorResolvebyRS		udd_paramcode	
	DECLARE	@V_RecProcessStatusP	udd_flag		DECLARE	@V_RecProcessStatusE	udd_flag			DECLARE	@V_RecProcessStatusS	udd_flag		
	DECLARE	@V_ExtErrorType			udd_flag		DECLARE	@V_Error				udd_flag			DECLARE	@ErrorMsg				NVARCHAR(MAX)		
	DECLARE	@V_Hdoc					udd_int 		DECLARE	@V_SPName				udd_documentno		DECLARE	@V_ErrorSource			udd_text		
	DECLARE	@V_Doctype				udd_flag		DECLARE	@V_min					INT					DECLARE	@V_Max					INT				
	DECLARE	@Guid					udd_guid		DECLARE	@RowId					BIGINT				DECLARE	@V_BatchList			VARCHAR(4000)		
	DECLARE	@V_RecProcessStatusI	udd_flag		DECLARE @SourceName				udd_documentno		DECLARE @V_CtxtLanguageId		udd_ctxt_language
	DECLARE @V_XML					XML				DECLARE @V_errorid				Udd_ErrorID			DECLARE	@OrderType				udd_Description	
	DECLARE @v_ctxt_service			udd_Description	DECLARE @DestinationName		udd_documentno		DECLARE	@V_AllCtxtOuinstance	udd_ctxt_ouinstance
	DECLARE	@V_RecProcessStatusR	udd_flag		DECLARE	@StLSN					BINARY(10)			DECLARE	@EdLSN					BINARY(10)			
	DECLARE	@save_to_lsn			BINARY(10)		DECLARE	@V_AcregNo				udd_documentno		DECLARE	@V_acMSN				udd_serialno
	DECLARE	@V_XMLOUT				udd_nvarcharmax	DECLARE	@StgRowId				INT					DECLARE @Service_OU				INT
	DECLARE	@PO_NO					udd_documentno	declare @BatchId				udd_guid			DECLARE @V_Errorcode            [udd_Errorcode]	
	DECLARE @V_ErrorDesc           [udd_ErrorDesc]	declare	@V_ErrorProc			[udd_status]		DECLARE @V_ErrorLine			BIGINT	

		DECLARE @iRISTblInsert TABLE
								(				
								RowID			BIGINT IDENTITY(1,1),	MsgId			udd_guid,
								TranId			udd_guid,				StgRowId		Udd_Guid,
								DocumentNo		Udd_Partno
								);

	BEGIN TRY
	/* Assigning values to the table variable */
		SELECT 	@V_Ctxt_Ouinstance			=		@CtxtOuinstance_In
		SELECT	@V_AllCtxtOuinstance		=		0
		SELECT 	@V_InterfaceID				= 		@InterfaceId_In
		SELECT 	@V_TranID					= 		@TranId_In
		SELECT 	@V_DefaultDate				=	    DBO.RAS_GETDATE(@V_Ctxt_Ouinstance)
		SELECT 	@V_ExecStatusCError			=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ExecutionStatus','Completed With Error(s)')	
		SELECT 	@V_ExecStatusFail			=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ExecutionStatus','Failed')
		SELECT 	@V_ExecStatusSuccess		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ExecutionStatus','Success')
		SELECT 	@V_ExecStatusInprog			=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ExecutionStatus','Inprogress')
		SELECT 	@V_ErrorResolvebyRS			=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'ALL','Errorresolveby','ITM Business Users')
		SELECT 	@V_ExtErrorType				=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ExtErrorType','Business Error')
		SELECT	@V_Ctxt_User				=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','UserName','UserName')
		SELECT 	@V_RecProcessStatusP		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','Recexistsflag','Inprocess')
		SELECT 	@V_RecProcessStatusE		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','Recexistsflag','Error')
		SELECT 	@V_RecProcessStatusS		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','Recexistsflag','Success')
		SELECT	@V_RecProcessStatusR		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'ALL','RECEXISTSFLAG','REPROCESS')
		SELECT	@V_RecProcessStatusI		=		dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'ALL','RECEXISTSFLAG','INPROGRESS')
		SELECT 	@V_ErrorSource				=	    dbo.Int_Get_Parameter_Value(@V_AllCtxtOuinstance,'All','ErrorSource','Error Source from SP')
		SELECT	@V_AcregNo					=		dbo.Int_Get_Parameter_Value(@V_Ctxt_Ouinstance,@V_InterfaceID,'AcRegNo','AcRegNo')
		SELECT	@V_acMSN					=		dbo.Int_Get_Parameter_Value(@V_Ctxt_Ouinstance,@V_InterfaceID,'acMSN','acMSN')
		SELECT 	@V_SPNAME					=		'Intg_POCreate_Outb_SP'

		SELECT	@SourceName			=	SourceName,
				@DestinationName	=	DestinationName
		FROM	Intg_Interface_Master WITH (NOLOCK)
		WHERE	CompanyCode			=	@V_Ctxt_Ouinstance
		AND		InterfaceId			=	@V_InterfaceID

			--Reprocessing Logic
		IF @Processflag_In = 'Reprocess'
		BEGIN
			SELECT TOP 1
				   @MessageId_In		= 	MsgID,
				   @V_Ctxt_Ouinstance	=	Ouinstance
			 FROM  Intg_POCreate_Outb_Stg Stg WITH (NOLOCK)
			 WHERE Stg.RecProcessStatus =	 @V_RecProcessStatusR
			 ORDER BY CREATEDDATE ASC

			 UPDATE Stg
			 SET 	RecProcessStatus	 = @V_RecProcessStatusP,
					ErrorCode 			 = NULL,
					SuccessErrorMsg		 = NULL,
					ModifiedDate		 = @V_DefaultDate,
					TransactionID		 = @V_TranID
			 FROM	DBO.Intg_POCreate_Outb_Stg Stg	
			 WHERE	Stg.RecProcessStatus = @V_RecProcessStatusR
			 AND	Stg.MsgID 			 = @MessageId_In
		END	
		
		--Loading PO Creation Data to Stage Table
		IF @Processflag_In = 'New' 
		BEGIN			
				SELECT  @save_to_lsn = end_lsn	
				FROM	DBO.Intg_Execution_Log WITH (NOLOCK)
				WHERE	InterfaceId	=	@V_InterfaceId 
				
				IF @save_to_lsn IS NULL
					SELECT @save_to_lsn = avnappdb.sys.fn_cdc_get_min_lsn('DBO_PO_POHDR_PO_HEADER_CT')  
			
				SET @StLSN = avnappdb.sys.fn_cdc_increment_lsn(@save_to_lsn);  
				SET @EdLSN = avnappdb.sys.fn_cdc_get_max_lsn(); 				
	
				IF  @EdLSN <> @save_to_lsn
				BEGIN			
				
					INSERT INTO Intg_POCreate_Outb_Stg
					(	Ouinstance				,InterfaceId					,TransactionID		,	PO_No				,			
						PO_Type					,ShipToAddress					,AcRegNO			,	acMSN				,	
						ShipByAddress			,PO_Line_No						,Req_Date			,	Part_No				,	
						Order_Qty				,Uom							,PO_Priority		,	Part_Condition		,
						Remarks					,MsgId							,RecProcessStatus	,	CreatedDate			,	
						CreatedBy				,SourceName						,DestinationName	,	stgrowid 
					)
					SELECT DISTINCT
						POHDR_OUINSTANCE		,CASE	WHEN POHDR_OUINSTANCE=2		THEN 'INTPO01-2' 
														WHEN POHDR_OUINSTANCE=3		THEN 'INTPO01-3'
														WHEN POHDR_OUINSTANCE=4		THEN 'INTPO01-4' 
													ELSE @V_InterfaceId END		,@V_TranID				,POHDR_PO_NO			
						,CASE WHEN POHDR_PO_TYPE = 'G' THEN 'ZOOS'
							  WHEN POHDR_PO_TYPE = 'EXCHG' THEN 'ZOEX'
							  WHEN POHDR_PO_TYPE = 'WARRANTY' THEN 'Z003' 
							  ELSE  POHDR_PO_TYPE END		--NEED TO REVIEW
													,'0020003628'/*NEED TO REVIEW*/	,@V_AcregNo			,@V_acMSN				
						,LEFT(potmcn_ship_by,12)	,POITM_LINE_NO					,POHDR_PO_DATE		,POITM_PART_NO
						,POITM_ORDER_QTY_PUOM		,POITM_PURCHASE_UOM	,			CASE WHEN POHDR_PRIORITY = 'AOG' THEN '01'  
																						 WHEN  POHDR_PRIORITY = 'URG' THEN '02'	--need to review
																						 WHEN POHDR_PRIORITY = 'NRM' THEN '03' 
																						 ELSE  POHDR_PRIORITY END	

						,CASE WHEN POITM_PART_CONDITION = 'N' THEN 'IA20' --IA20 for new, IA14 for used JAA, IA24 for used FAA, IA34 for used dual release
						 ELSE 'IA20' END
						,POHDR_REMARKS			,@MessageId_In			,@V_RecProcessStatusP		,@V_DefaultDate			
						,@V_Ctxt_User			,@SourceName			,@DestinationName			,DENSE_RANK() over ( order by POHDR_PO_NO)

					FROM		AVNAPPDB.CDC.fn_cdc_get_net_changes_DBO_PO_POHDR_PO_HEADER_CT (@StLSN, @EdLSN, N'all')
					JOIN		PO_POITM_PO_ITEM_DETAILS WITH (NOLOCK)
					ON			POITM_OUINSTANCE	=	POHDR_OUINSTANCE
					AND			POITM_PO_NO			=	POHDR_PO_NO
					LEFT JOIN	PO_POTMCN_PO_TERMS_CONDNS WITH (NOLOCK)
					ON			POTMCN_OUINSTANCE	=	POHDR_OUINSTANCE
					AND			POTMCN_PO_NO		=	POHDR_PO_NO
					WHERE		POHDR_AMEND_NO		=	'0'
					AND			POHDR_PO_STATUS		=	'F'
					AND			POHDR_USER_STATUS	=	'AW-INT'
					
			
				-- UPDATE THE START LSN AND END LSN
				UPDATE	EL
				SET		start_lsn	=	 CONVERT(BINARY(10),@StLSN, 1)  ,
						end_lsn		=	 CONVERT(BINARY(10),@EdLSN, 1)  				
				FROM	DBO.Intg_Execution_Log EL
				WHERE	InterfaceId	=	@V_InterfaceId

				END

		END	


		INSERT INTO @iRISTblInsert(MsgId,TranId,StgRowId)
		SELECT	MsgId,Transactionid,StgRowId
		FROM	dbo.Intg_POCreate_Outb_Stg stg WITH(NOLOCK)
		WHERE	STG.TransactionId		=	@V_TranID
		AND		STG.Recprocessstatus	=	@V_RecProcessStatusP
	 
		 SELECT @V_Min	= MIN(StgRowId),
				@V_Max	= MAX(StgRowId)
		 FROM	@iRISTblInsert

		 WHILE (@V_Min <= @V_Max)
		 BEGIN

			SELECT	@StgRowId	=	0		
			SELECT	@V_XML		=	NULL

			SELECT	@StgRowId	=	StgRowId
			FROM	@iRISTblInsert
			WHERE	StgRowId	=	@V_Min

			SELECT	@V_Ctxt_Ouinstance	=	Ouinstance	,
					@V_InterfaceID		=	InterfaceID	,
					@PO_NO				=	PO_NO	
			FROM	dbo.Intg_POCreate_Outb_Stg stg WITH(NOLOCK)
			WHERE	STG.TransactionId		=	@V_TranID
			AND		STG.Recprocessstatus	=	@V_RecProcessStatusP
			AND		stg.StgRowId			=	@V_Min	

						SELECT @V_XML	=	(SELECT  (SELECT TOP 1
														PO_Type							AS 'DOC_TYPE',
														AcRegNO							AS 'HELI_MODEL',
														ISNULL(Remarks,'Test')			AS 'NOTE', -- Assuming 'Remarks' as 'NOTE' 
														(SELECT(SELECT DISTINCT 
																PO_Line_No							AS 'PO_ITM_NO',
																CONVERT(VARCHAR(40), Req_Date, 112) AS 'REQ_DATE',
																Part_No								AS 'MATERIAL',
																CAST(ORDER_QTY AS INT)				AS 'QTY',
																Uom									AS 'T_UNIT_ISO',
																PO_Priority							AS 'DLV_PRIO',
																Part_Condition						AS 'STORE_LOC',
																NULL								AS 'COND_VALUE',
																NULL								AS 'CURRENCY'
																FROM	Intg_POCreate_Outb_Stg WITH (NOLOCK) 
																WHERE	TransactionID	=	@V_TranID
																AND		StgRowId		=	@StgRowId	
																FOR XML PATH ('item'), TYPE)
															FOR XML PATH ('ORDER_ITEM'), TYPE),
			
														acMSN							AS 'HELI_SERNR',							
														PO_No							AS 'PURCH_NO_C',
														isnull(ShipByAddress,'AIR')		AS 'SHIP_METHOD',
														ShipToAddress					AS 'SHIP_TO'
														FROM   Intg_POCreate_Outb_Stg WITH (NOLOCK)     
														WHERE  TransactionID	=	@V_TranID
														AND	   StgRowId			=	@StgRowId		
														FOR XML PATH ('ZB2B_SO_CREATE_001'), TYPE))
	
			SELECT @V_XMLOUT = CAST(@V_XML AS NVARCHAR(MAX))

			IF EXISTS (SELECT 'X' FROM Intg_POCreate_Outb_Stg 	WHERE	StgRowId = @StgRowId	AND	Transactionid	 = @V_TranID and Recprocessstatus	=	@V_RecProcessStatusP)
			BEGIN

				SELECT @BatchId	=	NEWID()
			
				INSERT INTO	Intg_POCreate_Outb_iRIS	
					(Ouinstance	,	Interfaceid	,		Msgid			,		Transactionid	,	
					 Batchid	,	xmldata		,		Recprocessstatus,		Createddate		,
					 StgRowId	,	PO_NO		)
				SELECT	
					@V_Ctxt_Ouinstance	,		@V_InterfaceID			,		@MessageId_In			,@V_TranID		,
					@BatchId			,		ISNULL(@V_XMLOUT,'Y')	,		@V_RecProcessStatusP	,@V_DefaultDate	,
					@StgRowId			,		@PO_NO	
						
					UPDATE	STG 
					SET		Batchid				=	@BatchId
					FROM	Intg_POCreate_Outb_Stg STG
					WHERE	Transactionid		=	@V_TranID --nonclus
					AND		StgRowId			=	@StgRowId

			END

			SELECT @V_Min = @V_Min + 1

	END -- While Loop

		SELECT  @V_BatchList		=	COALESCE(@V_BatchList+';','')+ iRIS.batchid
		FROM    dbo.Intg_POCreate_Outb_iRIS iRIS WITH (NOLOCK)
		WHERE	MsgId				=	@MessageId_In
		AND		TransactionID		=	@V_TranID

		SELECT  ISNULL(@V_BatchList,'Y')	'Guid'		

	END TRY
	BEGIN CATCH	
		
		SELECT @V_ErrorCode		=	ERROR_NUMBER()
		SELECT @V_Errordesc		=	ERROR_MESSAGE()
		SELECT @V_ErrorProc		=	ERROR_PROCEDURE()
		SELECT @V_ErrorLine		=	ERROR_LINE()
		
		INSERT INTO dbo.Intg_ErrorLog
		 (	
				InterfaceId,		RowId,			TransactionId,		KeyValue,			ErrorMsg, 
				ErrorCode,			ErrorSource,	ErrorType,			CreatedDate,		ErrorResolveby, 
				ouinstance,			MsgId
		)	
		SELECT	InterfaceId,		Rowid,			@V_TranID,			PO_No,				CONCAT('Unexpected SQL Exception in SP: ,',@V_ErrorProc,'-',@V_ErrorLine,'-',@V_Errordesc),
				ERROR_LINE(),		'SP',			@V_ExtErrorType,	@V_DefaultDate,		@V_ErrorResolvebyRS, 
				@V_Ctxt_Ouinstance, @MessageId_In	
		FROM	Intg_POCreate_Outb_Stg WITH (NOLOCK)
		WHERE	TransactionID	=	@V_TranID
		
		UPDATE  Stg
		SET		RecProcessStatus	= @V_RecProcessStatusE,
				modifieddate		= @V_DefaultDate,
				Successerrormsg		= @ErrorMsg
		FROM	dbo.Intg_POCreate_Outb_Stg Stg
		WHERE	Stg.TransactionID	= @V_TranID
		

		UPDATE  iRIS
		SET		Recprocessstatus	= @V_RecProcessStatusE,
				Successerrormsg		= @ErrorMsg
		FROM	DBO.Intg_POCreate_Outb_iRIS iRIS
		WHERE	TransactionID	=	@V_TranID
			
		SELECT  ISNULL(@V_BatchList,'Y')	  'Guid'

	END CATCH
SET NOCOUNT OFF
END
