/* Preethi S    26-FEB-2024       APSI-1834 */
IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Execution_Log where InterfaceId ='INTPO01-2')
BEGIN
INSERT INTO Intg_Execution_Log (InterfaceId,CurrentDate,DateRangeLastRunDate,DateRangeCurrentDate,ModifiedDateTime)
VALUES	('INTPO01-2',GETDATE(),dbo.ras_getdate(2),NULL,NULL)
END

IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Execution_Log where InterfaceId ='INTPO01-3')
BEGIN
INSERT INTO Intg_Execution_Log (InterfaceId,CurrentDate,DateRangeLastRunDate,DateRangeCurrentDate,ModifiedDateTime)
VALUES	('INTPO01-3',GETDATE(),dbo.ras_getdate(3),NULL,NULL)
END

IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Execution_Log where InterfaceId ='INTPO01-4')
BEGIN
INSERT INTO Intg_Execution_Log (InterfaceId,CurrentDate,DateRangeLastRunDate,DateRangeCurrentDate,ModifiedDateTime)
VALUES	('INTPO01-4',GETDATE(),dbo.ras_getdate(4),NULL,NULL)
END
