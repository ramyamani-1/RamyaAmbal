/********************************************************************************************/
/*$$Filename	 : 	Intg_POCreate_Outb_Resp_SP												*/
/********************************************************************************************/
/* Component     : BASFLTLOG																*/
/* Procedure     : Intg_POCreate_Outb_Resp_SP												*/
/* Description   : SaleOrder creation response process SP from endpoint						*/
/*---------------------------------Development History--------------------------------------*/
/* Author        :	Preethi S																*/
/* Date          :	27-Feb-2024															    */
/* Org Version   :	APSI-1834																*/
/*---------------------------------Modification History-------------------------------------*/
/* Modified Author					Modified date						rtrackid			*/
/*------------------------------------------------------------------------------------------*/

CREATE PROCEDURE DBO.Intg_POCreate_Outb_Resp_SP
@CtxtOuinstance_In		ctxt_ouinstance		,
@InterfaceID_In			udd_InterfaceID		,
@messageId_In			udd_guid			,
@tranid					udd_guid			,
@StgRowId				INT					,
@BATCHID				udd_guid			,
@Documentno_In			udd_txt150			,
@Errormsg_In			udd_errlongdesc		,
@statuscode				udd_status			,
@ResponsePayload		udd_nvarcharmax
AS
BEGIN
SET NOCOUNT ON

	DECLARE @V_Errorcode            [udd_Errorcode]			,@V_ErrorDesc           [udd_ErrorDesc]			,@V_RecProcessStatusE	[udd_recprocessstatus],
			@V_RecProcessStatusR	[udd_recprocessstatus]	,@V_RecprocessstatusP	[udd_recprocessstatus]	,@V_RecprocessstatusS	[udd_recprocessstatus],
			@V_ErrorResolveby		[udd_paramcode]			,@V_ErrorMsg			[Udd_Errordesc]			,@V_InterfaceId			[udd_InterfaceID]		
			,@V_CtxtAllOuinstance	[udd_Ouinstance]		,@V_MessageID			[udd_Guid]			    ,@V_UserName			[udd_ctxt_user]			
			,@V_ErrorProc			[udd_status]			,@V_ErrorLine			BIGINT					,@V_DefaultDate			Udd_datetime1 
			
	SELECT	@V_CtxtAllOuinstance	=	0,	
			@V_RecProcessStatusP	=	DBO.Int_Get_Parameter_Value(@V_CtxtAllOuinstance,'ALL','RECEXISTSFLAG','INPROCESS')					,
			@V_RecProcessStatusE	=	DBO.Int_Get_Parameter_Value(@V_CtxtAllOuinstance,'ALL','RECEXISTSFLAG','ERROR')						,
			@V_RecProcessStatusR	=	DBO.Int_Get_Parameter_Value(@V_CtxtAllOuinstance,'ALL','RECEXISTSFLAG','REPROCESS')					,
			@V_RecProcessstatusS	=	DBO.Int_Get_Parameter_Value(@V_CtxtAllOuinstance,'All','RECEXISTSFLAG','SUCCESS')					,
			@V_UserName				=	DBO.Int_Get_Parameter_Value(@V_CtxtAllOuinstance,'ALL','CREATEDBY','CREATEDBY')						,
			@V_DefaultDate			=	DBO.RAS_GETDATE(@CtxtOuinstance_In)
	
	BEGIN TRY

		INSERT INTO Intg_POResp_Outb_Tbl
			(Ouinstance					 ,Msgid						 ,SaleDocNo				 ,SuccessErrorMsg	
			 ,XmlDataOut				 ,TouchpointId				 ,CreatedDate			 ,CreatedBy			,tranid	)
		SELECT
			@CtxtOuinstance_In			,@messageId_In				,@Documentno_In			,@Errormsg_In
			,@ResponsePayload			,@InterfaceID_In			,@V_DefaultDate			,@V_UserName,			@tranid	



			UPDATE iRIS				
			SET		RecProcessStatus	= CASE WHEN @statuscode ='200' THEN 	@V_RecprocessstatusS  ELSE @V_RecProcessstatusE END,
					SuccessErrorMsg		= CASE WHEN @statuscode ='200' THEN		@Errormsg_In		  ELSE 	@Errormsg_In		END,
					ModifiedDate		=	@V_DefaultDate
			FROM	DBO.Intg_POCreate_Outb_iRIS iRIS
			WHERE	Transactionid		=	@tranid
			AND		BATCHID				=	@BATCHID

			UPDATE	STG
			SET		SuccessErrorMsg		=	CASE WHEN @statuscode ='200' THEN		@Errormsg_In		  ELSE 	@Errormsg_In		END		,	
					RecProcessStatus	=	CASE WHEN @statuscode ='200' THEN 	@V_RecprocessstatusS	  ELSE @V_RecProcessstatusE END	,
					ModifiedDate		=	@V_DefaultDate			,
					ModifiedBy			=	@V_UserName				,
					SaleOrder_No		=	@Documentno_In			
			FROM	DBO.Intg_POCreate_Outb_Stg	STG	
			WHERE	Transactionid		=	@tranid
			AND		BATCHID				=	@BATCHID

				--Ramya
				IF EXISTS (SELECT 'X' FROM PO_POudi_user_def_info WITH(NOLOCK)			
						JOIN Intg_POCreate_Outb_Stg WITH(NOLOCK) 
						ON POUDI_OUINSTANCE			=	Ouinstance
						AND		POUDI_PO_NO			=	PO_No 
						WHERE	Transactionid		=	@tranid 
						AND		BATCHID				=	@BATCHID
						)

				BEGIN

					UPDATE INFO
					SET		POUDI_USER_DEF_DESC1	=	@Documentno_In	,
							POUDI_USER_DEF_REMARKS	=	LEFT(CONCAT(POUDI_USER_DEF_REMARKS,@Errormsg_In),255),
							POUDI_MODIFIED_DATE	=	@V_DefaultDate,
							POUDI_MODIFIED_BY		=	'INTGUSER'
					FROM	PO_POudi_user_def_info INFO
					JOIN	Intg_POCreate_Outb_Stg STG		WITH(NOLOCK)
					ON		POUDI_OUINSTANCE		=	Ouinstance
					AND		POUDI_PO_NO			=	PO_No
					WHERE	Transactionid		=	@tranid 	
					AND		BATCHID				=	@BATCHID	

				END 
				ELSE 
				BEGIN 
	
					INSERT INTO PO_POUDI_USER_DEF_INFO
					( 
					POUDI_OUINSTANCE		,POUDI_PO_NO			,POUDI_USER_DEF_DESC1		,POUDI_USER_DEF_OPT1,
					POUDI_USER_DEF_DESC2	,POUDI_USER_DEF_OPT2	,POUDI_USER_DEF_DESC3		,POUDI_USER_DEF_OPT3,
					POUDI_USER_DEF_DESC4	,POUDI_USER_DEF_OPT4	,POUDI_USER_DEF_REMARKS		,POUDI_CREATED_DATE,
					POUDI_CREATED_BY		,POUDI_MODIFIED_DATE	,POUDI_MODIFIED_BY
					)
					SELECT 
					POHDR_OUINSTANCE		,POHDR_PO_NO			,@Documentno_In				,NULL,
					NULL					,NULL					,NULL						,NULL,
					NULL					,NULL					,LEFT(@Errormsg_In,255)		,@V_DefaultDate,
					'INTGUSER'				,@V_DefaultDate				,'INTGUSER'				
					FROM 	Intg_POCreate_Outb_Stg STG	WITH (NOLOCK)
					JOIN	PO_POHDR_PO_HEADER			WITH (NOLOCK)
					ON		POHDR_OUINSTANCE		=	Ouinstance
					AND		POHDR_PO_NO				=	PO_No
					WHERE	Transactionid			=	@tranid 
					AND		BATCHID					=	@BATCHID

				END 
				

			INSERT INTO [DBO].[Intg_ErrorLog]
			(		InterfaceId		,	RowId		,	ErrorSource	,		ErrorCode	  ,		ErrorMsg	,	
					CreatedDate		,	KeyValue	,	MsgId		,		ouinstance,			TransactionId
			)
			SELECT	InterfaceId		,	STG.RowId	,	'SP'		,	@statuscode ,		@Errormsg_In	,
					@V_DefaultDate	,	PO_No		,	STG.MsgId	,	stg.Ouinstance,		stg.TransactionId	
			FROM	DBO.Intg_POCreate_Outb_Stg	STG	
			WHERE	Transactionid		=	@tranid 
			AND		BATCHID				=	@BATCHID
			AND		RecProcessStatus	=	@V_RecProcessstatusE	

	END TRY 
	BEGIN CATCH
	
		SELECT @V_ErrorCode		=	ERROR_NUMBER()
		SELECT @V_Errordesc		=	ERROR_MESSAGE()
		SELECT @V_ErrorProc		=	ERROR_PROCEDURE()
		SELECT @V_ErrorLine		=	ERROR_LINE()
   
		INSERT INTO [DBO].[Intg_ErrorLog]
		(		InterfaceId		,	RowId			,	ErrorSource		,	ErrorCode	,	ErrorMsg	,	
				CreatedDate		,	MsgId			,	ouinstance
		)
		SELECT	@InterfaceID_In	,	-915		,	'SP'			,	@V_ErrorCode , 
				CONCAT('Unexpected SQL Exception in SP: ,',@V_ErrorProc,'-',@V_ErrorLine,'-',@V_Errordesc)	,
				@V_DefaultDate	,	@messageId_In			,	@CtxtOuinstance_In	

	END CATCH
  SET NOCOUNT OFF
END

