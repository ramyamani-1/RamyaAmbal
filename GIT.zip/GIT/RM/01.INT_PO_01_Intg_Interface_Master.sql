/* Preethi S    26-FEB-2024       APSI-1834 */
IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Interface_Master where InterfaceId = 'INTPO01-2')
BEGIN  
INSERT dbo.Intg_Interface_Master 
(InterfaceId, InterfaceDesc, CompanyCode, CreatedDate, CreateBy, ModifiedDate, ModifiedBy, InterfaceType, SourceName, DestinationName, 
Methodology, Frequency, InterfaceGroup, Status, SourceSystemTZ, StoredProcedure, iRISFolder, ExcepUIExcludFlag, StgTableName, IRISTableName, 
InterfaceName) 
VALUES 
(N'INTPO01-2', N'Process Ramcos PO and Create Sales Order in AW software', N'2', GETDATE(), N'Intguser', GETDATE(),
N'Intguser', N'Outbound',  N'Ramco', N'ASESA', N'Web services; Synchronous;', N'Every 5 Mins', N'Leonardo Integration Solution', N'Active', N'Mexico Standard Time',
N'Intg_POCreate_Outb_SP', N'null', N'N', N'Intg_POCreate_Outb_Stg', N'Intg_POCreate_Outb_iRIS', N'INT-PO-CRE')
END

IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Interface_Master where InterfaceId = 'INTPO01-3')
BEGIN  
INSERT dbo.Intg_Interface_Master 
(InterfaceId, InterfaceDesc, CompanyCode, CreatedDate, CreateBy, ModifiedDate, ModifiedBy, InterfaceType, SourceName, DestinationName, 
Methodology, Frequency, InterfaceGroup, Status, SourceSystemTZ, StoredProcedure, iRISFolder, ExcepUIExcludFlag, StgTableName, IRISTableName, 
InterfaceName) 
VALUES 
(N'INTPO01-3', N'Process Ramcos PO and Create Sales Order in AW software', N'3', GETDATE(), N'Intguser', GETDATE(),
N'Intguser', N'Outbound',  N'Ramco', N'ASESA', N'Web services; Synchronous;', N'Every 5 Mins', N'Leonardo Integration Solution', N'Active', N'Mexico Standard Time',
N'Intg_POCreate_Outb_SP', N'null', N'N', N'Intg_POCreate_Outb_Stg', N'Intg_POCreate_Outb_iRIS', N'INT-PO-CRE')
END

IF NOT EXISTS(SELECT 'X' FROM DBO.Intg_Interface_Master where InterfaceId = 'INTPO01-4')
BEGIN  
INSERT dbo.Intg_Interface_Master 
(InterfaceId, InterfaceDesc, CompanyCode, CreatedDate, CreateBy, ModifiedDate, ModifiedBy, InterfaceType, SourceName, DestinationName, 
Methodology, Frequency, InterfaceGroup, Status, SourceSystemTZ, StoredProcedure, iRISFolder, ExcepUIExcludFlag, StgTableName, IRISTableName, 
InterfaceName) 
VALUES 
(N'INTPO01-4', N'Process Ramcos PO and Create Sales Order in AW software', N'4', GETDATE(), N'Intguser', GETDATE(),
N'Intguser', N'Outbound',  N'Ramco', N'ASESA', N'Web services; Synchronous;', N'Every 5 Mins', N'Leonardo Integration Solution', N'Active', N'Mexico Standard Time',
N'Intg_POCreate_Outb_SP', N'null', N'N', N'Intg_POCreate_Outb_Stg', N'Intg_POCreate_Outb_iRIS', N'INT-PO-CRE')
END
