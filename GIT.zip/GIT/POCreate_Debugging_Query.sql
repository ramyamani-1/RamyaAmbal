use integdb

/*
select * from depdb..fw_admin_user with(nolock) where  username ='superuser'
select * from intg_interface_master with(nolock) where interfaceid='INT-PO-01'

exec Intg_POCreate_Outb_SP

select top 10 * from Intg_POCreate_Outb_iRIS	 with(nolock) order by rowid desc 
select top 10  * from Intg_POCreate_Outb_Stg	 with(nolock) order by rowid desc 

use avnappdb
SELECT is_cdc_enabled, * FROM  sys.databases WHERE name ='avnappdb'
SELECT * FROM sys.tables  WHERE name like  '%PO_POHDR_PO_HEADER%' AND is_tracked_by_cdc=1
*/

SELECT * FROM EMOD_OU_MST

select POITM_PART_CONDITION,* from PO_POITM_PO_ITEM_DETAILS where  POITM_PART_NO='6F6220L00751'

select potmcn_ship_by, * from PO_POHDR_PO_HEADER  WITH (NOLOCK)
JOIN	PO_POITM_PO_ITEM_DETAILS WITH (NOLOCK)
ON		POITM_OUINSTANCE	=	POHDR_OUINSTANCE
AND		POITM_PO_NO			=	POHDR_PO_NO
LEFT JOIN	po_potmcn_po_terms_condns WITH (NOLOCK)
ON		POTMCN_OUINSTANCE	=	POHDR_OUINSTANCE
AND		POTMCN_PO_NO		=	POHDR_PO_NO
WHERE	POITM_PART_NO='6F6220L00751'



UPDATE A 
SET		 POHDR_REMARKS  ='Test4',POHDR_USER_STATUS	=	'AW-INT'
FROM	PO_POHDR_PO_HEADER A
WHERE 	POHDR_OUINSTANCE=3
AND		POHDR_PO_NO IN ('PO3-000620-2024','PO3-000545-2023')

SELECT * FROM PO_POHDR_PO_HEADER A
WHERE 	POHDR_OUINSTANCE=3
AND 		POHDR_AMEND_NO		=	'0'
AND			POHDR_PO_STATUS		=	'F'


select * from Intg_POResp_Outb_Tbl order by rowid desc 
select * from avnappdb.cdc.DBO_PO_POHDR_PO_HEADER_CT_ct

begin tran
EXEC Intg_POCreate_Outb_SP 2,'INT-PO-01','155d746a-ab44-45','TRNID20240412003','NEW'
select  RecProcessStatus,	SuccessErrorMsg,* from Intg_POCreate_Outb_Stg	 with(nolock) where TransactionID='TRNID20240412003'  order by rowid desc 
select  RecProcessStatus,	SuccessErrorMsg,* from Intg_POCreate_Outb_iRIS	 with(nolock) where TransactionID='TRNID20240412003'  order by rowid desc 

ROLLBACK

select  * from Intg_POCreate_Outb_iRIS	 with(nolock) order by rowid desc 
select  * from Intg_POCreate_Outb_Stg	 with(nolock) order by rowid desc 

	UPDATE A
	SET RecProcessStatus	=	'R',
		SuccessErrorMsg		=	NULL
	FROM  Intg_POCreate_Outb_Stg A
	WHERE Rowid in  (10524,10525)

select newid()

SELECT GETDATE()
select  TOP 5 * from intg_errorlog  with(nolock) order by seqno desc 





	begin tran
	exec Intg_POCreate_Outb_Resp_SP
	@CtxtOuinstance_In	=2,
	@InterfaceID_In		='INT-PO-01',
	@messageId_In		='4ac11fd6-f7f1-4f95-bcfb-48764cce421d',
	@tranid				='RTRNID_20240412034629.6294688',
	@Documentno_In		='<SALESDOCUMENT/>',
	@Errormsg_In		='<ERR_MSG><item><ERROR_MESSAGE>Material 6F6220V00452 does not exist in storage location US03 IA20</ERROR_MESSAGE></item><item><ERROR_MESSAGE>Error in SALES_ITEM_IN 000010</ERROR_MESSAGE></item><item><ERROR_MESSAGE>Sales document  was not changed</ERROR_MESSAGE></item></ERR_MSG>',
	@statuscode			='200 OK',
	@ResponsePayload	='JSON',
	@StgRowId	='1',
	@BATCHID	='397E97B3-C751-48CA-A824-D6650F2C066E'
--	select  RecProcessStatus,	SuccessErrorMsg,* from Intg_POCreate_Outb_Stg	 with(nolock) where TransactionID='RTRNID_20240412034629.6294688'  order by rowid desc 
--select  RecProcessStatus,	SuccessErrorMsg,* from Intg_POCreate_Outb_iRIS	 with(nolock) where TransactionID='RTRNID_20240412034629.6294688'  order by rowid desc 
SELECT * FROM PO_POudi_user_def_info  with(nolock)
	rollback



	